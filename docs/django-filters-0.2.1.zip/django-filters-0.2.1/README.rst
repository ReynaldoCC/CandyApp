====================
Django Filters
====================

The Django Filters project is created for easy filter creation.
There are slug and get base filters and an BaseFilterset for constructing.


Upcoming features
============

If you have ideas for other features please let me know.

Installation
============

#. pip install git+git://github.com/baskoopmans/django-filters.git

#. Or add the `filters` directory to your Python path.

#. Add `filters` to your INSTALLED_APPS if you want to use templates and templatetags

Configuration
=============


TODOs and BUGS
==============

See: http://github.com/baskoopmans/django-filters/issues
