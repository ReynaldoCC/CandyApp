VERSION = (0, 2, 1)
__version__ = '.'.join(map(str, VERSION))
